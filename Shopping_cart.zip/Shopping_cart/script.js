// Enhanced Product Data (now with 20 products)
const products = [
    {
        id: 1,
        name: "Women's Denim Jacket",
        category: "women",
        price: 3999,
        originalPrice: 6499,
        rating: 4,
        ratingCount: 124,
        image: "https://images.unsplash.com/photo-1542272604-787c3835535d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1026&q=80",
        isNew: false,
        onSale: true,
        description: "Stylish denim jacket for women with comfortable fit and trendy design. Perfect for casual outings.",
        sizes: ["S", "M", "L", "XL"],
        colors: ["Blue", "Black", "White"],
        details: ["100% Cotton", "Machine wash", "Slim fit", "Front button closure"]
    },
    {
        id: 2,
        name: "Men's White T-Shirt",
        category: "men",
        price: 1599,
        originalPrice: 2399,
        rating: 4.5,
        ratingCount: 89,
        image: "https://images.unsplash.com/photo-1529374255404-311a2a4f1fd9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1259&q=80",
        isNew: true,
        onSale: true,
        description: "Classic white t-shirt for men made from premium cotton for all-day comfort.",
        sizes: ["S", "M", "L", "XL", "XXL"],
        colors: ["White", "Black", "Gray"],
        details: ["100% Cotton", "Machine wash", "Regular fit", "Round neck"]
    },
    {
        id: 3,
        name: "Women's Summer Dress",
        category: "women",
        price: 3299,
        originalPrice: 3299,
        rating: 5,
        ratingCount: 215,
        image: "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=687&q=80",
        isNew: true,
        onSale: false,
        description: "Lightweight summer dress with floral pattern, perfect for warm weather occasions.",
        sizes: ["XS", "S", "M", "L"],
        colors: ["Floral", "Blue", "Pink"],
        details: ["Polyester blend", "Hand wash recommended", "A-line silhouette", "V-neck"]
    },
    {
        id: 4,
        name: "Men's Formal Shirt",
        category: "men",
        price: 2899,
        originalPrice: 4149,
        rating: 4,
        ratingCount: 76,
        image: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=736&q=80",
        isNew: false,
        onSale: true,
        description: "Premium formal shirt for men with slim fit and wrinkle-resistant fabric.",
        sizes: ["S", "M", "L", "XL"],
        colors: ["White", "Blue", "Gray"],
        details: ["100% Cotton", "Machine wash", "Slim fit", "Button-down collar"]
    },
    {
        id: 5,
        name: "Kids Printed T-Shirt",
        category: "kids",
        price: 999,
        originalPrice: 1499,
        rating: 4.5,
        ratingCount: 42,
        image: "https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1025&q=80",
        isNew: false,
        onSale: true,
        description: "Fun printed t-shirt for kids with cartoon characters and comfortable fabric.",
        sizes: ["2-4Y", "4-6Y", "6-8Y", "8-10Y"],
        colors: ["Red", "Blue", "Green"],
        details: ["100% Cotton", "Machine wash", "Regular fit", "Short sleeves"]
    },
    {
        id: 6,
        name: "Women's Handbag",
        category: "accessories",
        price: 2499,
        originalPrice: 3499,
        rating: 4,
        ratingCount: 68,
        image: "https://images.unsplash.com/photo-1590874103328-eac38a683ce7?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=738&q=80",
        isNew: false,
        onSale: true,
        description: "Stylish women's handbag with multiple compartments and durable material.",
        colors: ["Black", "Brown", "Beige"],
        details: ["Genuine leather", "Wipe clean only", "Adjustable strap", "Zipper closure"]
    },
    {
        id: 7,
        name: "Men's Sneakers",
        category: "men",
        price: 4599,
        originalPrice: 4599,
        rating: 4.5,
        ratingCount: 132,
        image: "https://images.unsplash.com/photo-1600269452121-4f2416e55c28?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=765&q=80",
        isNew: true,
        onSale: false,
        description: "Comfortable sneakers for men with cushioned soles and breathable material.",
        sizes: ["7", "8", "9", "10", "11"],
        colors: ["White", "Black", "Blue"],
        details: ["Mesh upper", "Rubber sole", "Cushioned insole", "Lace-up closure"]
    },
    {
        id: 8,
        name: "Women's Sunglasses",
        category: "accessories",
        price: 1799,
        originalPrice: 2499,
        rating: 3.5,
        ratingCount: 57,
        image: "https://images.unsplash.com/photo-1511499767150-a48a237f0083?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=880&q=80",
        isNew: false,
        onSale: true,
        description: "Fashionable sunglasses for women with UV protection and trendy frame.",
        colors: ["Black", "Brown", "Tortoise"],
        details: ["100% UV protection", "Plastic frame", "Polarized lenses", "Includes case"]
    },
    {
        id: 9,
        name: "Women's Running Shoes",
        category: "women",
        price: 3899,
        originalPrice: 4999,
        rating: 4.7,
        ratingCount: 98,
        image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
        isNew: false,
        onSale: true,
        description: "High-performance running shoes for women with responsive cushioning.",
        sizes: ["5", "6", "7", "8", "9"],
        colors: ["Pink", "Black", "White"],
        details: ["Breathable mesh", "Rubber outsole", "Cushioned midsole", "Lace-up closure"]
    },
    {
        id: 10,
        name: "Men's Watch",
        category: "accessories",
        price: 5999,
        originalPrice: 7999,
        rating: 4.8,
        ratingCount: 156,
        image: "https://images.unsplash.com/photo-1523170335258-f5ed11844a49?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1480&q=80",
        isNew: false,
        onSale: true,
        description: "Elegant men's wristwatch with stainless steel case and leather strap.",
        colors: ["Black", "Brown", "Silver"],
        details: ["Stainless steel case", "Genuine leather strap", "Water resistant", "Quartz movement"]
    },
    {
        id: 11,
        name: "Kids Backpack",
        category: "kids",
        price: 1299,
        originalPrice: 1999,
        rating: 4.3,
        ratingCount: 37,
        image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=687&q=80",
        isNew: true,
        onSale: true,
        description: "Colorful backpack for kids with multiple compartments and comfortable straps.",
        colors: ["Blue", "Pink", "Green"],
        details: ["Polyester material", "Adjustable straps", "Front pocket", "Zipper closure"]
    },
    {
        id: 12,
        name: "Women's Jeans",
        category: "women",
        price: 2299,
        originalPrice: 2999,
        rating: 4.2,
        ratingCount: 84,
        image: "https://images.unsplash.com/photo-1473966968600-fa801b869a1a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=687&q=80",
        isNew: false,
        onSale: true,
        description: "Comfortable women's jeans with stretch fabric and stylish design.",
        sizes: ["24", "26", "28", "30", "32"],
        colors: ["Blue", "Black", "Gray"],
        details: ["98% Cotton, 2% Elastane", "Machine wash", "Slim fit", "Five-pocket style"]
    },
    {
        id: 13,
        name: "Men's Winter Jacket",
        category: "men",
        price: 6999,
        originalPrice: 8999,
        rating: 4.6,
        ratingCount: 112,
        image: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=736&q=80",
        isNew: true,
        onSale: true,
        description: "Warm winter jacket for men with water-resistant outer shell.",
        sizes: ["S", "M", "L", "XL", "XXL"],
        colors: ["Black", "Navy", "Gray"],
        details: ["Polyester outer", "Insulated lining", "Hooded", "Zipper closure"]
    },
    {
        id: 14,
        name: "Women's Scarf",
        category: "accessories",
        price: 899,
        originalPrice: 1299,
        rating: 4.1,
        ratingCount: 45,
        image: "https://images.unsplash.com/photo-1516762689617-e1cffcef479d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=711&q=80",
        isNew: false,
        onSale: true,
        description: "Soft and warm scarf for women with beautiful patterns.",
        colors: ["Red", "Blue", "Green", "Purple"],
        details: ["100% Wool", "Hand wash", "Fringed ends", "One size"]
    },
    {
        id: 15,
        name: "Men's Wallet",
        category: "accessories",
        price: 1499,
        originalPrice: 1999,
        rating: 4.4,
        ratingCount: 67,
        image: "https://images.unsplash.com/photo-1600857544200-b2f666a9a2ec?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=687&q=80",
        isNew: false,
        onSale: true,
        description: "Sleek men's wallet with multiple card slots and ID window.",
        colors: ["Black", "Brown", "Tan"],
        details: ["Genuine leather", "6 card slots", "ID window", "Bifold design"]
    },
    {
        id: 16,
        name: "Kids Winter Boots",
        category: "kids",
        price: 1999,
        originalPrice: 2499,
        rating: 4.5,
        ratingCount: 28,
        image: "https://images.unsplash.com/photo-1543503103-f94a0036ed9d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
        isNew: true,
        onSale: true,
        description: "Warm and waterproof winter boots for kids with fun designs.",
        sizes: ["10", "11", "12", "13", "1", "2"],
        colors: ["Pink", "Blue", "Black"],
        details: ["Waterproof outer", "Fleece lining", "Hook-and-loop closure", "Non-slip sole"]
    },
    {
        id: 17,
        name: "Women's Yoga Pants",
        category: "women",
        price: 1799,
        originalPrice: 2299,
        rating: 4.7,
        ratingCount: 143,
        image: "https://images.unsplash.com/photo-1584483766114-2cea6facdf57?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=764&q=80",
        isNew: false,
        onSale: true,
        description: "High-waisted yoga pants with stretchy, breathable fabric.",
        sizes: ["XS", "S", "M", "L", "XL"],
        colors: ["Black", "Gray", "Navy"],
        details: ["88% Polyester, 12% Spandex", "Machine wash", "High waist", "Pocket"]
    },
    {
        id: 18,
        name: "Men's Gym Shorts",
        category: "men",
        price: 1299,
        originalPrice: 1599,
        rating: 4.3,
        ratingCount: 76,
        image: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=736&q=80",
        isNew: false,
        onSale: true,
        description: "Lightweight gym shorts for men with moisture-wicking fabric.",
        sizes: ["S", "M", "L", "XL"],
        colors: ["Black", "Gray", "Blue"],
        details: ["100% Polyester", "Machine wash", "Elastic waistband", "Side pockets"]
    },
    {
        id: 19,
        name: "Women's Earrings",
        category: "accessories",
        price: 699,
        originalPrice: 999,
        rating: 4.2,
        ratingCount: 89,
        image: "https://images.unsplash.com/photo-1602173574767-37ac01994b2a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=735&q=80",
        isNew: true,
        onSale: true,
        description: "Elegant hoop earrings for women with sterling silver finish.",
        colors: ["Silver", "Gold"],
        details: ["Nickel-free", "Hypoallergenic", "1.5 inch diameter", "Butterfly backs"]
    },
    {
        id: 20,
        name: "Men's Belt",
        category: "accessories",
        price: 1199,
        originalPrice: 1599,
        rating: 4.0,
        ratingCount: 54,
        image: "https://images.unsplash.com/photo-1590856029826-c7a73142bbf1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=687&q=80",
        isNew: false,
        onSale: true,
        description: "Classic men's leather belt with durable buckle and adjustable fit.",
        sizes: ["30", "32", "34", "36", "38"],
        colors: ["Black", "Brown"],
        details: ["Genuine leather", "Brass buckle", "Adjustable", "1.5 inch width"]
    }
];

// Cart and Wishlist Data
let cart = JSON.parse(localStorage.getItem('cart')) || [];
let wishlist = JSON.parse(localStorage.getItem('wishlist')) || [];
let currentPage = 1;
const productsPerPage = 8;
let selectedColors = [];
let selectedSizes = [];

// DOM Elements
const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
const nav = document.querySelector('nav ul');
const productGrid = document.querySelector('.product-grid');
const cartCountElements = document.querySelectorAll('.cart-count');
const wishlistCountElements = document.querySelectorAll('.wishlist-count');
const cartItemsContainer = document.getElementById('cart-items-container');
const cartItemCount = document.getElementById('cart-item-count');
const subtotalElement = document.getElementById('subtotal');
const shippingElement = document.getElementById('shipping');
const discountElement = document.getElementById('discount');
const totalElement = document.getElementById('total');
const filterButtons = document.querySelectorAll('.filter-btn');
const sortSelect = document.getElementById('sort');
const categoryTitle = document.getElementById('category-title');
const paginationContainer = document.querySelector('.pagination');
const priceRangeSlider = document.querySelector('.price-range-slider');
const minPriceInput = document.getElementById('min-price');
const maxPriceInput = document.getElementById('max-price');
const colorOptions = document.querySelectorAll('.color-option');
const sizeOptions = document.querySelectorAll('.size-option');
const applyFiltersBtn = document.querySelector('.apply-filters');
const resetPriceBtn = document.querySelector('.reset-price');
const resetColorsBtn = document.querySelector('.reset-colors');
const resetSizesBtn = document.querySelector('.reset-sizes');
const wishlistContainer = document.querySelector('.wishlist-container');
const profileContainer = document.querySelector('.profile-container');

// Initialize the page
document.addEventListener('DOMContentLoaded', function() {
    updateCartCount();
    updateWishlistCount();
    
    // Load products on home page
    if (productGrid && window.location.pathname.includes('index.html')) {
        loadFeaturedProducts();
        
        // Category cards navigation
        document.querySelectorAll('.category-card').forEach(card => {
            card.addEventListener('click', function() {
                const category = this.querySelector('h3').textContent.toLowerCase()
                    .replace("'s", "").replace(" fashion", "").replace(" collection", "").trim();
                window.location.href = `products.html?category=${category}`;
            });
        });

        // Shop Now button redirect to New Arrivals
        document.querySelector('.hero .cta-button')?.addEventListener('click', function() {
            window.location.href = 'products.html?category=new';
        });
    }
    
    // Load products on products page
    if (productGrid && window.location.pathname.includes('products.html')) {
        initializeFilters();
        loadAllProducts();
    }
    
    // Load cart items on cart page
    if (cartItemsContainer) {
        loadCartItems();
        updateCartSummary();
    }
    
    // Load wishlist items on wishlist page
    if (wishlistContainer) {
        loadWishlistItems();
    }
    
    // Load profile data on profile page
    if (profileContainer) {
        loadProfileData();
    }
    
    // Load product details on product details page
    if (document.querySelector('.product-details')) {
        loadProductDetails();
    }
});

// Mobile menu toggle
if (mobileMenuBtn) {
    mobileMenuBtn.addEventListener('click', () => {
        nav.style.display = nav.style.display === 'flex' ? 'none' : 'flex';
    });
}

// Initialize filters
function initializeFilters() {
    // Price range slider
    if (priceRangeSlider) {
        priceRangeSlider.addEventListener('input', function() {
            const maxPrice = parseInt(this.value);
            maxPriceInput.value = maxPrice;
        });
    }

    // Min price input
    if (minPriceInput) {
        minPriceInput.addEventListener('change', function() {
            if (parseInt(this.value) > parseInt(maxPriceInput.value)) {
                this.value = maxPriceInput.value;
            }
            priceRangeSlider.min = this.value || 0;
        });
    }

    // Max price input
    if (maxPriceInput) {
        maxPriceInput.addEventListener('change', function() {
            if (parseInt(this.value) < parseInt(minPriceInput.value)) {
                this.value = minPriceInput.value;
            }
            priceRangeSlider.value = this.value || 10000;
        });
    }

    // Color selection
    if (colorOptions) {
        colorOptions.forEach(option => {
            option.addEventListener('click', function() {
                const color = this.dataset.color;
                this.classList.toggle('selected');
                
                if (this.classList.contains('selected')) {
                    if (!selectedColors.includes(color)) {
                        selectedColors.push(color);
                    }
                } else {
                    selectedColors = selectedColors.filter(c => c !== color);
                }
            });
        });
    }

    // Size selection
    if (sizeOptions) {
        sizeOptions.forEach(option => {
            option.addEventListener('click', function() {
                const size = this.dataset.size;
                this.classList.toggle('selected');
                
                if (this.classList.contains('selected')) {
                    if (!selectedSizes.includes(size)) {
                        selectedSizes.push(size);
                    }
                } else {
                    selectedSizes = selectedSizes.filter(s => s !== size);
                }
            });
        });
    }

    // Reset buttons
    if (resetPriceBtn) {
        resetPriceBtn.addEventListener('click', resetPriceFilter);
    }
    
    if (resetColorsBtn) {
        resetColorsBtn.addEventListener('click', resetColorFilter);
    }
    
    if (resetSizesBtn) {
        resetSizesBtn.addEventListener('click', resetSizeFilter);
    }

    // Apply filters button
    if (applyFiltersBtn) {
        applyFiltersBtn.addEventListener('click', function() {
            currentPage = 1;
            loadAllProducts();
        });
    }

    // Filter buttons
    if (filterButtons) {
        filterButtons.forEach(button => {
            button.addEventListener('click', function() {
                filterButtons.forEach(btn => btn.classList.remove('active'));
                this.classList.add('active');
                currentPage = 1;
                loadAllProducts();
            });
        });
    }

    // Sort select
    if (sortSelect) {
        sortSelect.addEventListener('change', function() {
            currentPage = 1;
            loadAllProducts();
        });
    }
}

// Reset filters
function resetPriceFilter() {
    minPriceInput.value = '';
    maxPriceInput.value = '';
    priceRangeSlider.value = 5000;
}

function resetColorFilter() {
    selectedColors = [];
    colorOptions.forEach(option => option.classList.remove('selected'));
}

function resetSizeFilter() {
    selectedSizes = [];
    sizeOptions.forEach(option => option.classList.remove('selected'));
}

// Load featured products (for home page)
function loadFeaturedProducts() {
    productGrid.innerHTML = '';
    
    // Get first 8 products
    const featuredProducts = products.slice(0, 8);
    
    featuredProducts.forEach(product => {
        productGrid.appendChild(createProductCard(product));
    });
}

// Load all products (for products page)
function loadAllProducts() {
    productGrid.innerHTML = '';
    
    // Get active filter from URL or button
    const urlParams = new URLSearchParams(window.location.search);
    let category = urlParams.get('category');
    
    // If no category in URL, check active filter button
    if (!category) {
        const activeFilter = document.querySelector('.filter-btn.active');
        category = activeFilter ? activeFilter.dataset.category : 'all';
    } else {
        // Update active button based on URL
        filterButtons.forEach(btn => {
            if (btn.dataset.category === category) {
                btn.classList.add('active');
            } else {
                btn.classList.remove('active');
            }
        });
    }
    
    // Update category title
    const categoryName = category.charAt(0).toUpperCase() + category.slice(1);
    if (categoryTitle) {
        categoryTitle.textContent = category === 'all' ? 'All Products' : 
                                  category === 'new' ? 'New Arrivals' : 
                                  category === 'sale' ? 'On Sale' : categoryName;
    }
    
    // Get other filter values
    const sortOption = sortSelect ? sortSelect.value : 'popular';
    let minPrice = minPriceInput ? parseInt(minPriceInput.value) || 0 : 0;
    let maxPrice = maxPriceInput ? parseInt(maxPriceInput.value) || Infinity : Infinity;
    
    // Filter products
    let filteredProducts = [...products];
    
    // Category filter
    if (category !== 'all') {
        if (category === 'new') {
            filteredProducts = filteredProducts.filter(product => product.isNew);
        } else if (category === 'sale') {
            filteredProducts = filteredProducts.filter(product => product.onSale);
        } else {
            filteredProducts = filteredProducts.filter(product => product.category === category);
        }
    }
    
    // Price filter
    filteredProducts = filteredProducts.filter(product => 
        product.price >= minPrice && product.price <= maxPrice
    );
    
    // Color filter
    if (selectedColors.length > 0) {
        filteredProducts = filteredProducts.filter(product => 
            product.colors && product.colors.some(color => selectedColors.includes(color))
        );
    }
    
    // Size filter
    if (selectedSizes.length > 0) {
        filteredProducts = filteredProducts.filter(product => 
            product.sizes && product.sizes.some(size => selectedSizes.includes(size.toLowerCase()))
        );
    }
    
    // Sort products
    switch (sortOption) {
        case 'newest':
            filteredProducts.sort((a, b) => b.id - a.id);
            break;
        case 'price-low':
            filteredProducts.sort((a, b) => a.price - b.price);
            break;
        case 'price-high':
            filteredProducts.sort((a, b) => b.price - a.price);
            break;
        case 'rating':
            filteredProducts.sort((a, b) => b.rating - a.rating);
            break;
        default: // popular
            filteredProducts.sort((a, b) => b.ratingCount - a.ratingCount);
    }
    
    // Pagination
    const totalPages = Math.ceil(filteredProducts.length / productsPerPage);
    const startIndex = (currentPage - 1) * productsPerPage;
    const paginatedProducts = filteredProducts.slice(startIndex, startIndex + productsPerPage);
    
    // Display products
    if (paginatedProducts.length > 0) {
        paginatedProducts.forEach(product => {
            const productCard = createProductCard(product);
            productCard.addEventListener('click', (e) => {
                if (!e.target.closest('.add-to-cart, .wishlist-icon')) {
                    window.location.href = `product-details.html?id=${product.id}`;
                }
            });
            productGrid.appendChild(productCard);
        });
        
        // Update pagination
        if (paginationContainer) {
            updatePagination(totalPages);
        }
    } else {
        productGrid.innerHTML = '<p class="no-products">No products found matching your criteria.</p>';
        if (paginationContainer) {
            paginationContainer.innerHTML = '';
        }
    }
}

// Update pagination controls
function updatePagination(totalPages) {
    paginationContainer.innerHTML = '';
    
    // Previous button
    const prevButton = document.createElement('button');
    prevButton.className = 'pagination-btn';
    prevButton.innerHTML = '<i class="fas fa-chevron-left"></i>';
    prevButton.disabled = currentPage === 1;
    prevButton.addEventListener('click', () => {
        if (currentPage > 1) {
            currentPage--;
            loadAllProducts();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
    });
    paginationContainer.appendChild(prevButton);
    
    // Page buttons
    const maxVisiblePages = 5;
    let startPage = Math.max(1, currentPage - Math.floor(maxVisiblePages / 2));
    let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);
    
    if (endPage - startPage + 1 < maxVisiblePages) {
        startPage = Math.max(1, endPage - maxVisiblePages + 1);
    }
    
    for (let i = startPage; i <= endPage; i++) {
        const pageButton = document.createElement('button');
        pageButton.className = `pagination-btn ${i === currentPage ? 'active' : ''}`;
        pageButton.textContent = i;
        pageButton.addEventListener('click', () => {
            currentPage = i;
            loadAllProducts();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
        paginationContainer.appendChild(pageButton);
    }
    
    // Next button
    const nextButton = document.createElement('button');
    nextButton.className = 'pagination-btn';
    nextButton.innerHTML = '<i class="fas fa-chevron-right"></i>';
    nextButton.disabled = currentPage === totalPages;
    nextButton.addEventListener('click', () => {
        if (currentPage < totalPages) {
            currentPage++;
            loadAllProducts();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
    });
    paginationContainer.appendChild(nextButton);
}

// Create product card element
function createProductCard(product) {
    const productCard = document.createElement('div');
    productCard.className = 'product-card';
    productCard.dataset.id = product.id;
    
    // Calculate discount percentage
    const discountPercentage = product.originalPrice ? 
        Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100) : 0;
    
    // Create stars for rating
    let stars = '';
    const fullStars = Math.floor(product.rating);
    const hasHalfStar = product.rating % 1 >= 0.5;
    
    for (let i = 1; i <= 5; i++) {
        if (i <= fullStars) {
            stars += '<i class="fas fa-star"></i>';
        } else if (i === fullStars + 1 && hasHalfStar) {
            stars += '<i class="fas fa-star-half-alt"></i>';
        } else {
            stars += '<i class="far fa-star"></i>';
        }
    }
    
    // Check if product is in wishlist
    const isInWishlist = wishlist.some(item => item.id === product.id);
    
    productCard.innerHTML = `
        <div class="product-image">
            <img src="${product.image}" alt="${product.name}">
            <div class="wishlist-icon ${isInWishlist ? 'active' : ''}">
                <i class="${isInWishlist ? 'fas' : 'far'} fa-heart"></i>
            </div>
        </div>
        <div class="product-info">
            <h3 class="product-title">${product.name}</h3>
            <div class="product-price">
                <span class="current-price">₹${product.price.toLocaleString()}</span>
                ${product.originalPrice && product.originalPrice > product.price ? 
                    `<span class="original-price">₹${product.originalPrice.toLocaleString()}</span>
                    <span class="discount">${discountPercentage}% OFF</span>` : ''}
            </div>
            <div class="product-rating">
                ${stars}
                <span class="rating-count">(${product.ratingCount})</span>
            </div>
            <button class="add-to-cart">Add to Cart</button>
        </div>
    `;
    
    // Add event listeners
    const addToCartBtn = productCard.querySelector('.add-to-cart');
    const wishlistIcon = productCard.querySelector('.wishlist-icon');
    
    addToCartBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        addToCart(product);
    });
    
    wishlistIcon.addEventListener('click', (e) => {
        e.stopPropagation();
        toggleWishlist(product, wishlistIcon);
    });
    
    return productCard;
}

// Add product to cart
function addToCart(product) {
    // Check if product already exists in cart
    const existingItem = cart.find(item => item.id === product.id);
    
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({
            ...product,
            quantity: 1
        });
    }
    
    // Save to localStorage
    localStorage.setItem('cart', JSON.stringify(cart));
    
    // Update cart count
    updateCartCount();
    
    // Show notification
    showNotification(`${product.name} has been added to your cart!`);
    
    // Update cart page if open
    if (cartItemsContainer) {
        loadCartItems();
        updateCartSummary();
    }
}

// Toggle product in wishlist
function toggleWishlist(product, wishlistIcon) {
    const isInWishlist = wishlist.some(item => item.id === product.id);
    
    if (isInWishlist) {
        // Remove from wishlist
        wishlist = wishlist.filter(item => item.id !== product.id);
        if (wishlistIcon) {
            wishlistIcon.classList.remove('active');
            wishlistIcon.innerHTML = '<i class="far fa-heart"></i>';
        }
    } else {
        // Add to wishlist
        wishlist.push(product);
        if (wishlistIcon) {
            wishlistIcon.classList.add('active');
            wishlistIcon.innerHTML = '<i class="fas fa-heart"></i>';
        }
    }
    
    // Save to localStorage
    localStorage.setItem('wishlist', JSON.stringify(wishlist));
    
    // Update wishlist count
    updateWishlistCount();
    
    // Update wishlist page if open
    if (wishlistContainer) {
        loadWishlistItems();
    }
    
    // Show notification
    showNotification(`${product.name} has been ${isInWishlist ? 'removed from' : 'added to'} your wishlist!`);
}

// Update cart count in header
function updateCartCount() {
    const count = cart.reduce((total, item) => total + item.quantity, 0);
    
    cartCountElements.forEach(element => {
        element.textContent = count;
    });
}

// Update wishlist count in header
function updateWishlistCount() {
    const count = wishlist.length;
    
    wishlistCountElements.forEach(element => {
        element.textContent = count;
    });
}

// Load cart items on cart page
function loadCartItems() {
    if (cart.length === 0) {
        cartItemsContainer.innerHTML = `
            <div class="cart-empty">
                <i class="fas fa-shopping-cart"></i>
                <h3>Your cart is empty</h3>
                <p>Looks like you haven't added anything to your cart yet</p>
                <a href="products.html" class="cta-button">Continue Shopping</a>
            </div>
        `;
        return;
    }
    
    let cartItemsHTML = '';
    
    cart.forEach(item => {
        const discount = item.originalPrice ? item.originalPrice - item.price : 0;
        
        cartItemsHTML += `
            <div class="cart-item" data-id="${item.id}">
                <div class="cart-item-img">
                    <img src="${item.image}" alt="${item.name}">
                </div>
                <div class="cart-item-details">
                    <h3>${item.name}</h3>
                    <p>Size: M</p>
                    <p>Color: Black</p>
                    <div class="cart-item-actions">
                        <button class="remove-item">Remove</button>
                        <button class="save-later">Save for later</button>
                    </div>
                </div>
                <div class="cart-item-price">
                    <span class="current-price">₹${(item.price * item.quantity).toLocaleString()}</span>
                    ${item.originalPrice ? 
                        `<span class="original-price">₹${(item.originalPrice * item.quantity).toLocaleString()}</span>` : ''}
                    <div class="quantity-control">
                        <button class="decrease-qty">-</button>
                        <input type="number" value="${item.quantity}" min="1">
                        <button class="increase-qty">+</button>
                    </div>
                </div>
            </div>
        `;
    });
    
    cartItemsContainer.innerHTML = cartItemsHTML;
    
    // Add event listeners for quantity controls
    document.querySelectorAll('.decrease-qty').forEach(button => {
        button.addEventListener('click', function() {
            const itemId = parseInt(this.closest('.cart-item').dataset.id);
            updateCartItemQuantity(itemId, -1);
        });
    });
    
    document.querySelectorAll('.increase-qty').forEach(button => {
        button.addEventListener('click', function() {
            const itemId = parseInt(this.closest('.cart-item').dataset.id);
            updateCartItemQuantity(itemId, 1);
        });
    });
    
    document.querySelectorAll('.remove-item').forEach(button => {
        button.addEventListener('click', function() {
            const itemId = parseInt(this.closest('.cart-item').dataset.id);
            removeCartItem(itemId);
        });
    });
    
    document.querySelectorAll('.save-later').forEach(button => {
        button.addEventListener('click', function() {
            const itemId = parseInt(this.closest('.cart-item').dataset.id);
            saveForLater(itemId);
        });
    });
    
    // Update quantity when input changes
    document.querySelectorAll('.quantity-control input').forEach(input => {
        input.addEventListener('change', function() {
            const itemId = parseInt(this.closest('.cart-item').dataset.id);
            const newQuantity = parseInt(this.value) || 1;
            updateCartItemQuantity(itemId, 0, newQuantity);
        });
    });
}

// Load wishlist items on wishlist page
function loadWishlistItems() {
    if (wishlist.length === 0) {
        wishlistContainer.innerHTML = `
            <div class="wishlist-empty">
                <i class="far fa-heart"></i>
                <h3>Your wishlist is empty</h3>
                <p>Looks like you haven't added anything to your wishlist yet</p>
                <a href="products.html" class="cta-button">Browse Products</a>
            </div>
        `;
        return;
    }
    
    let wishlistHTML = '<div class="wishlist-grid">';
    
    wishlist.forEach(item => {
        const discountPercentage = item.originalPrice ? 
            Math.round(((item.originalPrice - item.price) / item.originalPrice) * 100) : 0;
        
        wishlistHTML += `
            <div class="wishlist-item" data-id="${item.id}">
                <div class="wishlist-item-img">
                    <img src="${item.image}" alt="${item.name}">
                    <button class="remove-wishlist-item"><i class="fas fa-times"></i></button>
                </div>
                <div class="wishlist-item-details">
                    <h3>${item.name}</h3>
                    <div class="wishlist-item-price">
                        <span class="current-price">₹${item.price.toLocaleString()}</span>
                        ${item.originalPrice ? 
                            `<span class="original-price">₹${item.originalPrice.toLocaleString()}</span>
                            <span class="discount">${discountPercentage}% OFF</span>` : ''}
                    </div>
                    <button class="move-to-cart">Add to Cart</button>
                </div>
            </div>
        `;
    });
    
    wishlistHTML += '</div>';
    wishlistContainer.innerHTML = wishlistHTML;
    
    // Add event listeners
    document.querySelectorAll('.remove-wishlist-item').forEach(button => {
        button.addEventListener('click', function() {
            const itemId = parseInt(this.closest('.wishlist-item').dataset.id);
            removeFromWishlist(itemId);
        });
    });
    
    document.querySelectorAll('.move-to-cart').forEach(button => {
        button.addEventListener('click', function() {
            const itemId = parseInt(this.closest('.wishlist-item').dataset.id);
            moveToCart(itemId);
        });
    });
    
    // Make wishlist items clickable
    document.querySelectorAll('.wishlist-item').forEach(item => {
        item.addEventListener('click', function(e) {
            // Only navigate if click wasn't on a button
            if (!e.target.closest('button')) {
                const itemId = this.dataset.id;
                window.location.href = `product-details.html?id=${itemId}`;
            }
        });
    });
}

// Remove item from wishlist
function removeFromWishlist(itemId) {
    const itemIndex = wishlist.findIndex(item => item.id === itemId);
    
    if (itemIndex !== -1) {
        const item = wishlist[itemIndex];
        wishlist.splice(itemIndex, 1);
        localStorage.setItem('wishlist', JSON.stringify(wishlist));
        updateWishlistCount();
        loadWishlistItems();
        showNotification(`${item.name} has been removed from your wishlist!`);
    }
}

// Move item from wishlist to cart
function moveToCart(itemId) {
    const itemIndex = wishlist.findIndex(item => item.id === itemId);
    
    if (itemIndex !== -1) {
        const item = wishlist[itemIndex];
        
        // Add to cart
        const existingItem = cart.find(cartItem => cartItem.id === item.id);
        
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cart.push({
                ...item,
                quantity: 1
            });
        }
        
        // Remove from wishlist
        wishlist.splice(itemIndex, 1);
        
        // Update storage
        localStorage.setItem('cart', JSON.stringify(cart));
        localStorage.setItem('wishlist', JSON.stringify(wishlist));
        
        // Update counts
        updateCartCount();
        updateWishlistCount();
        
        // Update displays
        if (cartItemsContainer) {
            loadCartItems();
            updateCartSummary();
        }
        loadWishlistItems();
        
        showNotification(`${item.name} has been moved to your cart!`);
    }
}

// Load profile data
function loadProfileData() {
    // In a real app, this would come from your backend
    const profileData = {
        name: "Priya Sharma",
        email: "priya.sharma@example.com",
        phone: "+91 9876543210",
        address: "123 Fashion Street, Mumbai, Maharashtra 400001",
        orders: [
            { id: 1001, date: "2023-05-15", total: 8598, status: "Delivered" },
            { id: 1002, date: "2023-06-22", total: 3299, status: "Shipped" },
            { id: 1003, date: "2023-07-10", total: 1499, status: "Processing" }
        ]
    };
    
    profileContainer.innerHTML = `
        <div class="profile-section">
            <h2>Personal Information</h2>
            <div class="profile-info">
                <div class="info-row">
                    <span class="info-label">Name:</span>
                    <span class="info-value">${profileData.name}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Email:</span>
                    <span class="info-value">${profileData.email}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Phone:</span>
                    <span class="info-value">${profileData.phone}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Address:</span>
                    <span class="info-value">${profileData.address}</span>
                </div>
                <button class="edit-profile-btn">Edit Profile</button>
            </div>
        </div>
        
        <div class="profile-section">
            <h2>Order History</h2>
            <div class="orders-table">
                <table>
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Date</th>
                            <th>Total</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${profileData.orders.map(order => `
                            <tr>
                                <td>#${order.id}</td>
                                <td>${order.date}</td>
                                <td>₹${order.total.toLocaleString()}</td>
                                <td><span class="status-${order.status.toLowerCase()}">${order.status}</span></td>
                                <td><a href="#" class="view-order">View</a></td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        </div>
    `;
}

// Load product details
function loadProductDetails() {
    const urlParams = new URLSearchParams(window.location.search);
    const productId = parseInt(urlParams.get('id'));
    
    if (isNaN(productId)) {
        window.location.href = 'products.html';
        return;
    }
    
    const product = products.find(p => p.id === productId);
    
    if (!product) {
        window.location.href = 'products.html';
        return;
    }
    
    const productDetailsContainer = document.querySelector('.product-details');
    const discountPercentage = product.originalPrice ? 
        Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100) : 0;
    
    // Create stars for rating
    let stars = '';
    const fullStars = Math.floor(product.rating);
    const hasHalfStar = product.rating % 1 >= 0.5;
    
    for (let i = 1; i <= 5; i++) {
        if (i <= fullStars) {
            stars += '<i class="fas fa-star"></i>';
        } else if (i === fullStars + 1 && hasHalfStar) {
            stars += '<i class="fas fa-star-half-alt"></i>';
        } else {
            stars += '<i class="far fa-star"></i>';
        }
    }
    
    // Check if product is in wishlist
    const isInWishlist = wishlist.some(item => item.id === product.id);
    
    productDetailsContainer.innerHTML = `
        <div class="product-images">
            <div class="main-image">
                <img src="${product.image}" alt="${product.name}">
            </div>
            <div class="thumbnail-images">
                <img src="${product.image}" alt="${product.name}">
                <img src="${product.image}" alt="${product.name}">
                <img src="${product.image}" alt="${product.name}">
            </div>
        </div>
        <div class="product-info">
            <h1>${product.name}</h1>
            <div class="product-rating">
                ${stars}
                <span class="rating-count">${product.rating} (${product.ratingCount} reviews)</span>
                <a href="#" class="write-review">Write a review</a>
            </div>
            <div class="product-price">
                <span class="current-price">₹${product.price.toLocaleString()}</span>
                ${product.originalPrice ? 
                    `<span class="original-price">₹${product.originalPrice.toLocaleString()}</span>
                    <span class="discount">${discountPercentage}% OFF</span>` : ''}
            </div>
            <p class="product-description">${product.description}</p>
            
            ${product.sizes ? `
            <div class="product-option">
                <h3>Size</h3>
                <div class="size-options">
                    ${product.sizes.map(size => `
                        <button class="size-option">${size}</button>
                    `).join('')}
                </div>
            </div>` : ''}
            
            ${product.colors ? `
            <div class="product-option">
                <h3>Color</h3>
                <div class="color-options">
                    ${product.colors.map(color => `
                        <button class="color-option" style="background-color: ${color.toLowerCase()}" title="${color}"></button>
                    `).join('')}
                </div>
            </div>` : ''}
            
            <div class="product-quantity">
                <h3>Quantity</h3>
                <div class="quantity-control">
                    <button class="decrease-qty">-</button>
                    <input type="number" value="1" min="1">
                    <button class="increase-qty">+</button>
                </div>
            </div>
            
            <div class="product-actions">
                <button class="add-to-cart-btn">Add to Cart</button>
                <button class="wishlist-btn ${isInWishlist ? 'in-wishlist' : ''}">
                    <i class="${isInWishlist ? 'fas' : 'far'} fa-heart"></i>
                    ${isInWishlist ? 'In Wishlist' : 'Add to Wishlist'}
                </button>
            </div>
            
            <div class="product-details">
                <h3>Product Details</h3>
                <ul>
                    ${product.details.map(detail => `<li>${detail}</li>`).join('')}
                </ul>
            </div>
        </div>
    `;
    
    // Add event listeners
    const addToCartBtn = document.querySelector('.add-to-cart-btn');
    const wishlistBtn = document.querySelector('.wishlist-btn');
    const quantityInput = document.querySelector('.product-quantity input');
    const decreaseBtn = document.querySelector('.product-quantity .decrease-qty');
    const increaseBtn = document.querySelector('.product-quantity .increase-qty');
    
    addToCartBtn.addEventListener('click', () => {
        const quantity = parseInt(quantityInput.value) || 1;
        addToCart({...product, quantity});
    });
    
    wishlistBtn.addEventListener('click', () => {
        toggleWishlist(product, wishlistBtn);
    });
    
    decreaseBtn.addEventListener('click', () => {
        const currentValue = parseInt(quantityInput.value) || 1;
        if (currentValue > 1) {
            quantityInput.value = currentValue - 1;
        }
    });
    
    increaseBtn.addEventListener('click', () => {
        const currentValue = parseInt(quantityInput.value) || 1;
        quantityInput.value = currentValue + 1;
    });
    
    quantityInput.addEventListener('change', function() {
        if (this.value < 1 || isNaN(this.value)) {
            this.value = 1;
        }
    });
}

// Update cart item quantity
function updateCartItemQuantity(itemId, change, newQuantity = null) {
    const itemIndex = cart.findIndex(item => item.id === itemId);
    
    if (itemIndex !== -1) {
        if (newQuantity !== null) {
            cart[itemIndex].quantity = Math.max(1, newQuantity);
        } else {
            cart[itemIndex].quantity = Math.max(1, cart[itemIndex].quantity + change);
        }
        
        // Save to localStorage
        localStorage.setItem('cart', JSON.stringify(cart));
        
        // Update cart display
        if (cartItemsContainer) {
            loadCartItems();
            updateCartSummary();
        }
        updateCartCount();
    }
}

// Remove item from cart
function removeCartItem(itemId) {
    const itemIndex = cart.findIndex(item => item.id === itemId);
    
    if (itemIndex !== -1) {
        const item = cart[itemIndex];
        cart.splice(itemIndex, 1);
        
        // Save to localStorage
        localStorage.setItem('cart', JSON.stringify(cart));
        
        // Update cart display
        loadCartItems();
        updateCartSummary();
        updateCartCount();
        
        showNotification(`${item.name} has been removed from your cart!`);
    }
}

// Save item for later (move to wishlist)
function saveForLater(itemId) {
    const itemIndex = cart.findIndex(item => item.id === itemId);
    
    if (itemIndex !== -1) {
        const item = cart[itemIndex];
        
        // Check if item already exists in wishlist
        if (!wishlist.some(wishItem => wishItem.id === item.id)) {
            wishlist.push(item);
            localStorage.setItem('wishlist', JSON.stringify(wishlist));
            updateWishlistCount();
        }
        
        // Remove from cart
        cart.splice(itemIndex, 1);
        localStorage.setItem('cart', JSON.stringify(cart));
        
        // Update cart display
        loadCartItems();
        updateCartSummary();
        updateCartCount();
        
        showNotification(`${item.name} has been moved to your wishlist!`);
    }
}

// Update cart summary (subtotal, shipping, etc.)
function updateCartSummary() {
    const subtotal = cart.reduce((total, item) => total + (item.price * item.quantity), 0);
    const shipping = subtotal > 5000 ? 0 : 99;
    const discount = cart.reduce((total, item) => {
        return total + (item.originalPrice ? (item.originalPrice - item.price) * item.quantity : 0);
    }, 0);
    const total = subtotal + shipping - discount;
    
    subtotalElement.textContent = `₹${subtotal.toLocaleString()}`;
    shippingElement.textContent = shipping === 0 ? 'FREE' : `₹${shipping.toLocaleString()}`;
    discountElement.textContent = `-₹${discount.toLocaleString()}`;
    totalElement.textContent = `₹${total.toLocaleString()}`;
    cartItemCount.textContent = cart.reduce((total, item) => total + item.quantity, 0);
}

// Show notification
function showNotification(message) {
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.textContent = message;
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.classList.add('show');
    }, 10);
    
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}